# KURBR Product-Market Fit Validation Plan

**Timeline:** May 14 - June 14, 2026 (30 days)
**Budget:** $5,000
**Goal:** 30 completed jobs

## Success Metrics

By June 14, 2026:
- ✅ 30+ jobs completed
- ✅ 15+ active haulers recruited
- ✅ $1,800+ revenue ($60 avg platform fee × 30 jobs)
- ✅ 80%+ customer satisfaction
- ✅ <$100 customer acquisition cost
- ✅ 50%+ hauler utilization

## Budget Allocation

- **$2,000** - Customer acquisition (ads)
- **$1,000** - Operating expenses (insurance, gas, dump fees)
- **$500** - Tools/services (Twilio, Stripe fees when added)
- **$1,500** - Reserve/contingency

## Phase 1: Manual Operations (Week 1-2)

**Days 1-3: Supply Side**
- Recruit 15-20 haulers from pole signs
- Create hauler tracking spreadsheet
- Manual dispatch via SMS

**Days 4-7: Demand Side**
- Post in 10+ Facebook groups
- Post on Nextdoor in 5+ areas
- Launch Facebook ads ($20/day)
- Process first 3-5 jobs manually

**Payment:** Venmo/Zelle (manual, no Stripe yet)

## Phase 2: Add Automation (Week 3-4)

**If first 10 jobs successful:**
- Add Stripe payment processing
- Add Twilio SMS dispatch
- Implement auto-matching haulers to jobs

**If struggling:**
- Adjust pricing
- Refine target audience
- Test different ad creative
- Expand to more Facebook groups

## Week 1 Target: 5 jobs
## Week 2 Target: 10 jobs (15 total)
## Week 3 Target: 10 jobs (25 total)
## Week 4 Target: 5+ jobs (30+ total)

## Decision Point (June 14)

**If successful (hit targets):**
- Invest in scaling (more ads, more cities)
- Hire part-time operations help
- Build toward $20K/month profit goal

**If unsuccessful (<20 jobs):**
- Analyze what didn't work
- Pivot pricing, messaging, or target market
- Consider whether to continue or pivot