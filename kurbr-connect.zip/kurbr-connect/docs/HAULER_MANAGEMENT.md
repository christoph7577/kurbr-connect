# Hauler Recruitment & Management

## Finding Haulers

### Sources:
1. **Pole Signs** - Write down numbers from junk removal signs
2. **Nextdoor** - Search "junk removal" in local areas
3. **Facebook** - Local buy/sell/trade groups
4. **Google** - "junk removal [city]"
5. **Craigslist** - Services section
6. **Referrals** - Ask existing haulers

## Recruitment Script

**Phone call:**

> Hey [name], I'm Chris with KURBR. I'm building a platform that sends junk removal leads to haulers like you.
> Here's how it works:
>
> - We handle all marketing and customer acquisition
> - You get notified of jobs near you via text
> - You reply YES to accept the job
> - You keep 80% of the fee ($120-160 per job)
> - We handle payment processing
> - You focus on the work
>
> Interested in getting leads?

## Onboarding Process

1. **Collect Info:**
   - Name, phone, email
   - Truck type and capacity
   - Service area (cities/zip codes)
   - Insurance verification
   - W-9 for 1099 payments

2. **Add to System:**
   - Create profile in Supabase hauler_profiles table
   - Add to hauler tracking spreadsheet
   - Send welcome text with expectations

3. **Set Expectations:**
   - Response time: Reply within 5 minutes to job offers
   - Professional behavior required
   - Send before/after photos for verification
   - Payment: 80% within 48 hours of job completion

## Dispatch Process (Manual - Week 1-2)

1. New job comes in via website
2. Check admin dashboard
3. Text nearest available hauler:

```
New KURBR job:
Address: 123 Main St, South Jordan
Items: Couch, mattress, 3 bags
Payout: $144 (you keep 80%)
Date: Tomorrow 10am
Reply YES to accept
```

4. Hauler replies YES
5. Update job status to "dispatched"
6. Send customer confirmation with hauler details

## Dispatch Process (Automated - Week 3+)

1. New job comes in
2. AI matches nearest hauler based on:
   - Distance from job
   - Truck capacity vs. estimated volume
   - Current availability
   - Rating/acceptance history
3. Automatic SMS sent to hauler
4. Hauler replies YES or NO
5. If NO, send to next best match
6. Customer notified automatically

## Quality Control

**After Each Job:**
- Hauler uploads before/after photos
- Customer rates experience (1-5 stars)
- Review for any issues
- Release payment if job confirmed complete

**Warning System:**
- First issue: Verbal warning
- Second issue: Written warning
- Third issue: Suspension pending review
- Fourth issue: Removal from platform

## Payment to Haulers

**Current (Manual):**
- Hauler completes job
- Sends before/after photos
- Customer confirms completion
- You Venmo/Zelle hauler 80% within 24 hours

**Future (Automated with Stripe):**
- Payment automatically sent to hauler bank account
- 80% within 48 hours
- Automatic 1099 tracking
