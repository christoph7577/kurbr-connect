# Go-to-Market Strategy

## Phase 1: South Jordan Launch (Month 1)

**Target Market:**
- South Jordan, West Jordan, Sandy, Riverton
- Homeowners aged 30-65
- Household income $75K+
- Recent movers, renovators, downsizers

**Channels:**

### Organic (Free)

**Facebook Groups:**
- Join 10-15 local groups
- Post 2x/week (within group rules)
- Engage with other posts first (build trust)
- Message template:

```
🚛 Need junk removed? New service in South Jordan!
• Upload photos, get instant quote
• Book online in 2 minutes
• Transparent pricing, trusted haulers
• Launch special: $25 off first job
kurbr.com
```

**Nextdoor:**
- Post in 5-10 neighboring areas
- Respond to "need recommendations" posts
- Offer referral discounts

**Google Business Profile:**
- Set up free listing
- Post weekly updates
- Collect reviews from first customers

### Paid ($50-100/week)

**Facebook Ads:**
- Audience: South Jordan + 5 mile radius
- Age: 30-65
- Interests: Home improvement, moving, decluttering
- Budget: $20/day
- Creative: Before/after photos, "Book in 2 minutes" CTA

**Google Ads (Month 2):**
- Start with $30/day
- Keywords: "junk removal south jordan", "furniture removal", "haul away junk"
- Local service ads if available

### Partnerships

**Property Managers:**
- Target 20-30 companies
- Offer bulk pricing discount
- Fast response time guarantee
- Monthly billing option

**Real Estate Agents:**
- Partner for estate cleanouts
- Referral commission (10%)
- Fast turnaround for listings

**Home Renovation Companies:**
- Disposal partner for demo debris
- Discounted rates for regular work
- Quick response for urgent jobs

## Messaging Framework

**Value Props:**
1. **Convenience:** "Book in 2 minutes from your phone"
2. **Transparency:** "See your price before you book"
3. **Speed:** "Same-day pickup available"
4. **Trust:** "Insured, vetted haulers"
5. **Eco-friendly:** "We recycle and donate when possible"

**Customer Pain Points We Solve:**
- ❌ Not knowing the price upfront
- ❌ Waiting days for quotes
- ❌ Unreliable haulers
- ❌ Hidden fees
- ❌ Having to be home for estimate

## Content Calendar

**Week 1:** Launch announcement + customer testimonials
**Week 2:** Before/after photos + pricing transparency
**Week 3:** Meet the haulers + behind-the-scenes
**Week 4:** Customer success stories + referral program

## Metrics to Track

**Weekly:**
- Website visits
- Booking conversions
- Cost per acquisition
- Jobs completed
- Customer satisfaction
- Hauler utilization

**Monthly:**
- Revenue vs. expenses
- LTV:CAC ratio
- Repeat customer rate
- Referral rate
- Market share (jobs vs. competition)

## Expansion Plan

**Month 2:** Add Provo/Orem (2nd market)
**Month 3:** Add Ogden (3rd market)
**Month 4:** Add St. George (4th market)
**Month 5-6:** Optimize Utah before expanding out of state
